import java.awt.*;
import java.awt.event.*;
import java.sql.*;
public class InsertAnswer extends Panel 
{
	Button insertAnswerButton;
	TextField opt1Text, opt2Text, opt3Text, opt4Text, ansidText;
	TextArea errorText;
	Connection connection;
	Statement statement;
	public InsertAnswer() 
	{
		try 
		{
			Class.forName("oracle.jdbc.driver.OracleDriver");
		} 
		catch (Exception e) 
		{
			System.err.println("Unable to find and load driver");
			System.exit(1);
		}
		connectToDB();
	}

	public void connectToDB() 
    {
		try 
		{
		  connection = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","system","oracle");
		  statement = connection.createStatement();

		} 
		catch (SQLException connectException) 
		{
		  System.out.println(connectException.getMessage());
		  System.out.println(connectException.getSQLState());
		  System.out.println(connectException.getErrorCode());
		  System.exit(1);
		}
    }
	public void buildGUI() 
	{		
		//Handle Insert Account Button
		insertAnswerButton = new Button("Insert Answer");
		insertAnswerButton.addActionListener(new ActionListener() 
		{
			public void actionPerformed(ActionEvent e) 
			{
				try 
				{
				  Statement statement = connection.createStatement();
				  //String query = "INSERT INTO Answer (SID,SNAME, RATING, AGE) VALUES (2,'Divya',7,20)";				  
				  String query= "INSERT INTO Answer VALUES(" + ansidText.getText() + ", " + "'" + opt1Text.getText() + "'," + opt2Text.getText() + "," + opt3Text.getText() + "," + opt4Text.getText() +")";
				  int i = statement.executeUpdate(query);
				  errorText.append("\nInserted " + i + " rows successfully");
				} 
				catch (SQLException insertException) 
				{
				  displaySQLErrors(insertException);
				}
			}
		});

	
		ansidText = new TextField(15);
		opt1Text = new TextField(15);
		opt2Text = new TextField(15);
		opt3Text = new TextField(15);
		opt4Text = new TextField(15);

		
		errorText = new TextArea(10, 40);
		errorText.setEditable(false);

		Panel first = new Panel();
		first.setLayout(new GridLayout(5, 2));
		first.add(new Label("Answer ID:"));
		first.add(ansidText);
		first.add(new Label("Option 1:"));
		first.add(opt1Text);
		first.add(new Label("Option 2:"));
		first.add(opt2Text);
		first.add(new Label("Option 3:"));
		first.add(opt3Text);
		first.add(new Label("Option 4:"));
		first.add(opt4Text);
		first.setBounds(125,90,200,100);
		
		Panel second = new Panel(new GridLayout(4, 1));
		second.add(insertAnswerButton);
        second.setBounds(125,220,150,100);         
		
		Panel third = new Panel();
		third.add(errorText);
		third.setBounds(125,320,300,200);
		
		setLayout(null);

		add(first);
		add(second);
		add(third);
	    
		setSize(500, 600);
		setVisible(true);
	}

	

	private void displaySQLErrors(SQLException e) 

	{
		errorText.append("\nSQLException: " + e.getMessage() + "\n");
		errorText.append("SQLState:     " + e.getSQLState() + "\n");
		errorText.append("VendorError:  " + e.getErrorCode() + "\n");
	}

	

	public static void main(String[] args) 
	{
		InsertAnswer ans = new InsertAnswer();

			
		ans.buildGUI();
	}
}
