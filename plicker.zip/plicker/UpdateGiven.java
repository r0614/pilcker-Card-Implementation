import java.awt.*;
import java.awt.event.*;
import java.sql.*;
public class UpdateGiven extends Panel 
{
	Button UpdateGivenButton;
	List givenIDList;
	TextField noText, sidText;
	TextArea errorText;
	Connection connection;
	Statement statement;
	ResultSet rs;
	
	public UpdateGiven() 
	{
		try 
		{
			Class.forName("oracle.jdbc.driver.OracleDriver");
		} 
		catch (Exception e) 
		{
			System.err.println("Unable to find and load driver");
			System.exit(1);
		}
		connectToDB();
	}

	public void connectToDB() 
    {
		try 
		{
		  connection = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","system","oracle");
		  statement = connection.createStatement();

		} 
		catch (SQLException connectException) 
		{
		  System.out.println(connectException.getMessage());
		  System.out.println(connectException.getSQLState());
		  System.out.println(connectException.getErrorCode());
		  System.exit(1);
		}
    }
	
	private void loadgiven() 
	{	   
		try 
		{
		  rs = statement.executeQuery("SELECT * FROM given_ques");
		  while (rs.next()) 
		  {
			givenIDList.add(rs.getString("no"));
		  }
		} 
		catch (SQLException e) 
		{ 
		  displaySQLErrors(e);
		}
	}
	
	public void buildGUI() 
	{		
	    givenIDList = new List(6);
		loadgiven();
		add(givenIDList);
		
		//When a list item is selected populate the text fields
		givenIDList.addItemListener(new ItemListener()
		{
			public void itemStateChanged(ItemEvent e) 
			{
				try 
				{
					rs = statement.executeQuery("SELECT * FROM given_ques");
					while (rs.next()) 
					{
						if (rs.getString("no").equals(givenIDList.getSelectedItem()))
						break;
					}
					if (!rs.isAfterLast()) 
					{
						noText.setText(rs.getString("no"));
						sidText.setText(rs.getString("sid"));
						
					}
				} 
				catch (SQLException selectException) 
				{
					displaySQLErrors(selectException);
				}
			}
		});		
		
	    
		//Handle Update Sailor Button
		UpdateGivenButton = new Button("Update given_ques");
		UpdateGivenButton.addActionListener(new ActionListener()
		{
			public void actionPerformed(ActionEvent e) 
			{
				try 
				{
					Statement statement = connection.createStatement();
					int i = statement.executeUpdate("UPDATE given_ques "
					+ "SET sid=" + sidText.getText() + 
					 " WHERE no = "
					+ givenIDList.getSelectedItem());
					errorText.append("\nUpdated " + i + " rows successfully");
					givenIDList.removeAll();
					loadgiven();
				} 
				catch (SQLException insertException) 
				{
					displaySQLErrors(insertException);
				}
			}
		});
		
		noText = new TextField(15);
		noText.setEditable(false);
		sidText = new TextField(15);
		
		
		errorText = new TextArea(10, 40);
		errorText.setEditable(false);

		Panel first = new Panel();
		first.setLayout(new GridLayout(4, 2));
		first.add(new Label("ques  no:"));
		first.add(noText);
		first.add(new Label("Student ID:"));
		first.add(sidText);
		
		
		
		Panel second = new Panel(new GridLayout(4, 1));
		second.add(UpdateGivenButton);
		
		Panel third = new Panel();
		third.add(errorText);
		
		add(first);
		add(second);
		add(third);
	    
		setSize(500, 600);
		setLayout(new FlowLayout());
		setVisible(true);
		
	}

	private void displaySQLErrors(SQLException e) 
	{
		errorText.append("\nSQLException: " + e.getMessage() + "\n");
		errorText.append("SQLState:     " + e.getSQLState() + "\n");
		errorText.append("VendorError:  " + e.getErrorCode() + "\n");
	}

	public static void main(String[] args) 
	{
		UpdateGiven upg= new UpdateGiven();
		
		upg.buildGUI();
	}
}
