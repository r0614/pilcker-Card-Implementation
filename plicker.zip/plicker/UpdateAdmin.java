import java.awt.*;
import java.awt.event.*;
import java.sql.*;
public class UpdateAdmin extends Panel 
{
	Button UpdateAdminButton;
	List adminIDList;
	TextField aidText, anameText;
	TextArea errorText;
	Connection connection;
	Statement statement;
	ResultSet rs;
	
	public UpdateAdmin() 
	{
		try 
		{
			Class.forName("oracle.jdbc.driver.OracleDriver");
		} 
		catch (Exception e) 
		{
			System.err.println("Unable to find and load driver");
			System.exit(1);
		}
		connectToDB();
	}

	public void connectToDB() 
    {
		try 
		{
		  connection = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","system","oracle");
		  statement = connection.createStatement();

		} 
		catch (SQLException connectException) 
		{
		  System.out.println(connectException.getMessage());
		  System.out.println(connectException.getSQLState());
		  System.out.println(connectException.getErrorCode());
		  System.exit(1);
		}
    }
	
	private void loadadmin() 
	{	   
		try 
		{
		  rs = statement.executeQuery("SELECT * FROM admin");
		  while (rs.next()) 
		  {
			adminIDList.add(rs.getString("aid"));
		  }
		} 
		catch (SQLException e) 
		{ 
		  displaySQLErrors(e);
		}
	}
	
	public void buildGUI() 
	{		
	    adminIDList = new List(6);
		loadadmin();
		add(adminIDList);
		
		//When a list item is selected populate the text fields
		adminIDList.addItemListener(new ItemListener()
		{
			public void itemStateChanged(ItemEvent e) 
			{
				try 
				{
					rs = statement.executeQuery("SELECT * FROM admin");
					while (rs.next()) 
					{
						if (rs.getString("aid").equals(adminIDList.getSelectedItem()))
						break;
					}
					if (!rs.isAfterLast()) 
					{
						aidText.setText(rs.getString("aid"));
						anameText.setText(rs.getString("aname"));
						
					}
				} 
				catch (SQLException selectException) 
				{
					displaySQLErrors(selectException);
				}
			}
		});		
		
	    
		//Handle Update Sailor Button
		UpdateAdminButton = new Button("Update admin");
		UpdateAdminButton.addActionListener(new ActionListener()
		{
			public void actionPerformed(ActionEvent e) 
			{
				try 
				{
					Statement statement = connection.createStatement();
					int i = statement.executeUpdate("UPDATE admin "
					+ "SET aname='" + anameText.getText() + 
					 " 'WHERE aid = "
					+ adminIDList.getSelectedItem());
					errorText.append("\nUpdated " + i + " rows successfully");
					adminIDList.removeAll();
					loadadmin();
				} 
				catch (SQLException insertException) 
				{
					displaySQLErrors(insertException);
				}
			}
		});
		
		aidText = new TextField(15);
		aidText.setEditable(false);
		anameText = new TextField(15);
		
		
		errorText = new TextArea(10, 40);
		errorText.setEditable(false);

		Panel first = new Panel();
		first.setLayout(new GridLayout(4, 2));
		first.add(new Label("admin ID:"));
		first.add(aidText);
		first.add(new Label("Name:"));
		first.add(anameText);
		
		
		
		Panel second = new Panel(new GridLayout(4, 1));
		second.add(UpdateAdminButton);
		
		Panel third = new Panel();
		third.add(errorText);
		
		add(first);
		add(second);
		add(third);
	    
		setSize(500, 600);
		setLayout(new FlowLayout());
		setVisible(true);
		
	}

	private void displaySQLErrors(SQLException e) 
	{
		errorText.append("\nSQLException: " + e.getMessage() + "\n");
		errorText.append("SQLState:     " + e.getSQLState() + "\n");
		errorText.append("VendorError:  " + e.getErrorCode() + "\n");
	}

	public static void main(String[] args) 
	{
		UpdateAdmin upad = new UpdateAdmin();
		
		upad.buildGUI();
	}
}
