
import java.awt.*;
import java.awt.event.*;
import java.sql.*;
public class DeleteAnswer extends Panel 
{
	Button deleteAnswerButton;
	List answerIDList;
	TextField ansidText, opt1Text, opt2Text, opt3Text, opt4Text;
	TextArea errorText;
	Connection connection;
	Statement statement;
	ResultSet rs;
	
	public DeleteAnswer() 
	{
		try 
		{
			Class.forName("oracle.jdbc.driver.OracleDriver");
		} 
		catch (Exception e) 
		{
			System.err.println("Unable to find and load driver");
			System.exit(1);
		}
		connectToDB();
	}

	public void connectToDB() 
    {
		try 
		{
		  connection = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","system","oracle");
		  statement = connection.createStatement();

		} 
		catch (SQLException connectException) 
		{
		  System.out.println(connectException.getMessage());
		  System.out.println(connectException.getSQLState());
		  System.out.println(connectException.getErrorCode());
		  System.exit(1);
		}
    }
	
	private void loadAnswer() 
	{	   
		try 
		{
		  rs = statement.executeQuery("SELECT * FROM answer");
		  while (rs.next()) 
		  {
			answerIDList.add(rs.getString("ANSID"));
		  }
		} 
		catch (SQLException e) 
		{ 
		  displaySQLErrors(e);
		}
	}
	
	public void buildGUI() 
	{		
	    answerIDList = new List(10);
		loadAnswer();
		add(answerIDList);
		
		//When a list item is selected populate the text fields
		answerIDList.addItemListener(new ItemListener()
		{
			public void itemStateChanged(ItemEvent e) 
			{
				try 
				{
					rs = statement.executeQuery("SELECT * FROM answer");
					while (rs.next()) 
					{
						if (rs.getString("ANSID").equals(answerIDList.getSelectedItem()))
						break;
					}
					if (!rs.isAfterLast()) 
					{
						ansidText.setText(rs.getString("ANSID"));
						opt1Text.setText(rs.getString("OPT1"));
						opt2Text.setText(rs.getString("OPT2"));
						opt3Text.setText(rs.getString("OPT3"));
						opt4Text.setText(rs.getString("OPT4"));
					}
				} 
				catch (SQLException selectException) 
				{
					displaySQLErrors(selectException);
				}
			}
		});		
		
	    
		//Handle Delete Sailor Button
		deleteAnswerButton = new Button("Delete Answer");
		deleteAnswerButton.addActionListener(new ActionListener()
		{
			public void actionPerformed(ActionEvent e) 
			{
				try 
				{
					Statement statement = connection.createStatement();
					int i = statement.executeUpdate("DELETE FROM answer WHERE ANSID = "
							+ answerIDList.getSelectedItem());
					errorText.append("\nDeleted " + i + " rows successfully");
					ansidText.setText(null);
					opt1Text.setText(null);
					opt2Text.setText(null);
					opt3Text.setText(null);
					opt4Text.setText(null);
					answerIDList.removeAll();
					loadAnswer();
				} 
				catch (SQLException insertException) 
				{
					displaySQLErrors(insertException);
				}
			}
		});
		
		ansidText = new TextField(15);
		opt1Text = new TextField(15);
		opt2Text = new TextField(15);
		opt3Text = new TextField(15);
		opt4Text = new TextField(15);
		
		errorText = new TextArea(10, 40);
		errorText.setEditable(false);

		Panel first = new Panel();
		first.setLayout(new GridLayout(5, 2));
		first.add(new Label("Answer ID:"));
		first.add(ansidText);
		first.add(new Label("OPTION 1 :"));
		first.add(opt1Text);
		first.add(new Label("OPTION 2 :"));
		first.add(opt2Text);
		first.add(new Label("OPTION 3 :"));
		first.add(opt3Text);
		first.add(new Label("OPTION 4 :"));
		first.add(opt4Text);
		
		Panel second = new Panel(new GridLayout(4, 1));
		second.add(deleteAnswerButton);
		
		Panel third = new Panel();
		third.add(errorText);
		
		add(first);
		add(second);
		add(third);
	    
		setSize(450, 600);
		setLayout(new FlowLayout());
		setVisible(true);
		
	}

	

	private void displaySQLErrors(SQLException e) 
	{
		errorText.append("\nSQLException: " + e.getMessage() + "\n");
		errorText.append("SQLState:     " + e.getSQLState() + "\n");
		errorText.append("VendorError:  " + e.getErrorCode() + "\n");
	}

	

	public static void main(String[] args) 
	{
		DeleteAnswer delan = new DeleteAnswer();
		delan.buildGUI();
	}
}
