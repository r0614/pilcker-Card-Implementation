import java.awt.*;
import java.awt.event.*;
import java.sql.*;
public class UpdateCrctAnswer extends Panel 
{
	Button UpdateCrctAnswerButton;
	List answerIDList;
	TextField noText, ansidText;
	TextArea errorText;
	Connection connection;
	Statement statement;
	ResultSet rs;
	
	public UpdateCrctAnswer() 
	{
		try 
		{
			Class.forName("oracle.jdbc.driver.OracleDriver");
		} 
		catch (Exception e) 
		{
			System.err.println("Unable to find and load driver");
			System.exit(1);
		}
		connectToDB();
	}

	public void connectToDB() 
    {
		try 
		{
		  connection = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","system","oracle");
		  statement = connection.createStatement();

		} 
		catch (SQLException connectException) 
		{
		  System.out.println(connectException.getMessage());
		  System.out.println(connectException.getSQLState());
		  System.out.println(connectException.getErrorCode());
		  System.exit(1);
		}
    }
	
	private void loadanswer() 
	{	   
		try 
		{
		  rs = statement.executeQuery("SELECT * FROM crct_answer");
		  while (rs.next()) 
		  {
			answerIDList.add(rs.getString("no"));
		  }
		} 
		catch (SQLException e) 
		{ 
		  displaySQLErrors(e);
		}
	}
	
	public void buildGUI() 
	{		
	    answerIDList = new List(6);
		loadanswer();
		add(answerIDList);
		
		//When a list item is selected populate the text fields
		answerIDList.addItemListener(new ItemListener()
		{
			public void itemStateChanged(ItemEvent e) 
			{
				try 
				{
					rs = statement.executeQuery("SELECT * FROM crct_answer");
					while (rs.next()) 
					{
						if (rs.getString("no").equals(answerIDList.getSelectedItem()))
						break;
					}
					if (!rs.isAfterLast()) 
					{
						noText.setText(rs.getString("no"));
						ansidText.setText(rs.getString("ansid"));
						
					}
				} 
				catch (SQLException selectException) 
				{
					displaySQLErrors(selectException);
				}
			}
		});		
		
	    
		//Handle Update Sailor Button
		UpdateCrctAnswerButton = new Button("Update crct_answer");
		UpdateCrctAnswerButton.addActionListener(new ActionListener()
		{
			public void actionPerformed(ActionEvent e) 
			{
				try 
				{
					Statement statement = connection.createStatement();
					int i = statement.executeUpdate("UPDATE crct_answer "
					+ "SET ansid=" + ansidText.getText() + 
					 " WHERE no = "
					+ answerIDList.getSelectedItem());
					errorText.append("\nUpdated " + i + " rows successfully");
					answerIDList.removeAll();
					loadanswer();
				} 
				catch (SQLException insertException) 
				{
					displaySQLErrors(insertException);
				}
			}
		});
		
		noText = new TextField(15);
		noText.setEditable(false);
		ansidText = new TextField(15);
		
		
		errorText = new TextArea(10, 40);
		errorText.setEditable(false);

		Panel first = new Panel();
		first.setLayout(new GridLayout(4, 2));
		first.add(new Label("ques  no:"));
		first.add(noText);
		first.add(new Label("Name:"));
		first.add(ansidText);
		
		
		
		Panel second = new Panel(new GridLayout(4, 1));
		second.add(UpdateCrctAnswerButton);
		
		Panel third = new Panel();
		third.add(errorText);
		
		add(first);
		add(second);
		add(third);
	    
		setSize(500, 600);
		setLayout(new FlowLayout());
		setVisible(true);
		
	}

	private void displaySQLErrors(SQLException e) 
	{
		errorText.append("\nSQLException: " + e.getMessage() + "\n");
		errorText.append("SQLState:     " + e.getSQLState() + "\n");
		errorText.append("VendorError:  " + e.getErrorCode() + "\n");
	}

	public static void main(String[] args) 
	{
		UpdateCrctAnswer upansid= new UpdateCrctAnswer();
		
		upansid.buildGUI();
	}
}
