import java.awt.*;
import java.awt.event.*;
import java.sql.*;
public class UpdateInstructor extends Panel 
{
	Button UpdateInstructorButton;
	List InstructorIDList;
	TextField tidText, tnameText, subText, expText, tclassText;
	TextArea errorText;
	Connection connection;
	Statement statement;
	ResultSet rs;
	
	public UpdateInstructor() 
	{
		try 
		{
			Class.forName("oracle.jdbc.driver.OracleDriver");
		} 
		catch (Exception e) 
		{
			System.err.println("Unable to find and load driver");
			System.exit(1);
		}
		connectToDB();
	}

	public void connectToDB() 
    {
		try 
		{
		  connection = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","system","oracle");
		  statement = connection.createStatement();

		} 
		catch (SQLException connectException) 
		{
		  System.out.println(connectException.getMessage());
		  System.out.println(connectException.getSQLState());
		  System.out.println(connectException.getErrorCode());
		  System.exit(1);
		}
    }
	
	private void loadInstructor() 
	{	   
		try 
		{
		  rs = statement.executeQuery("SELECT * FROM Instructor");
		  while (rs.next()) 
		  {
			InstructorIDList.add(rs.getString("tid"));
		  }
		} 
		catch (SQLException e) 
		{ 
		  displaySQLErrors(e);
		}
	}
	
	public void buildGUI() 
	{		
	    InstructorIDList = new List(6);
		loadInstructor();
		add(InstructorIDList);
		
		//When a list item is selected populate the text fields
		InstructorIDList.addItemListener(new ItemListener()
		{
			public void itemStateChanged(ItemEvent e) 
			{
				try 
				{
					rs = statement.executeQuery("SELECT * FROM Instructor");
					while (rs.next()) 
					{
						if (rs.getString("tid").equals(InstructorIDList.getSelectedItem()))
						break;
					}
					if (!rs.isAfterLast()) 
					{
						tidText.setText(rs.getString("TID"));
						tnameText.setText(rs.getString("TNAME"));
						tclassText.setText(rs.getString("TCLASS"));
						
						subText.setText(rs.getString("SUB"));
						expText.setText(rs.getString("EXP"));
					}
				} 
				catch (SQLException selectException) 
				{
					displaySQLErrors(selectException);
				}
			}
		});		
		
	    
		//Handle Update Sailor Button
		UpdateInstructorButton = new Button("Update Instructor");
		UpdateInstructorButton.addActionListener(new ActionListener()
		{
			public void actionPerformed(ActionEvent e) 
			{
				try 
				{
					Statement statement = connection.createStatement();
					int i = statement.executeUpdate("UPDATE Instructor "
					+ "SET tname='" + tnameText.getText()  + "', "
					+ "tclass=" + tclassText.getText() +  ", "
					+ "exp=" + expText.getText() +  ", "
					+ "sub='" + subText.getText() +"' WHERE tid = "
					+ InstructorIDList.getSelectedItem());
					errorText.append("\nUpdated " + i + " rows successfully");
					InstructorIDList.removeAll();
					loadInstructor();
				} 
				catch (SQLException insertException) 
				{
					displaySQLErrors(insertException);
				}
			}
		});
		
		tidText = new TextField(15);
		tidText.setEditable(false);
		tnameText = new TextField(15);
		tclassText = new TextField(15);
		subText = new TextField(15);
		expText = new TextField(15);
		
		errorText = new TextArea(10, 40);
		errorText.setEditable(false);

		Panel first = new Panel();
		first.setLayout(new GridLayout(5, 2));
		first.add(new Label("Instructor ID:"));
		first.add(tidText);
		first.add(new Label("Name :"));
		first.add(tnameText);
		first.add(new Label("tclass :"));
		first.add(tclassText);
		first.add(new Label("sub :"));
		first.add(subText);
		first.add(new Label("exp :"));
		first.add(expText);

		
		Panel second = new Panel(new GridLayout(4, 1));
		second.add(UpdateInstructorButton);
		
		Panel third = new Panel();
		third.add(errorText);
		
		add(first);
		add(second);
		add(third);
	     
		setSize(500, 600);
		setLayout(new FlowLayout());
		setVisible(true);
		
	}

	private void displaySQLErrors(SQLException e) 
	{
		errorText.append("\nSQLException: " + e.getMessage() + "\n");
		errorText.append("SQLState:     " + e.getSQLState() + "\n");
		errorText.append("VendorError:  " + e.getErrorCode() + "\n");
	}

	public static void main(String[] args) 
	{
		UpdateInstructor upi = new UpdateInstructor();
		
		upi.buildGUI();
	}
}
