import java.awt.*;
import java.awt.event.*;
import java.sql.*;
public class crct_answer extends Panel 
{
	Button crctButton;
	
	Choice ansidSelect, noSelect;
	TextArea errorText;
	Connection connection;
	Statement statement;
	ResultSet rs;
	
	public crct_answer() 
	{
		try 
		{
			Class.forName("oracle.jdbc.driver.OracleDriver");
		} 
		catch (Exception e) 
		{
			System.err.println("Unable to find and load driver");
			System.exit(1);
		}
		connectToDB();
	}

	public void connectToDB() 
    {
		try 
		{
		  connection = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","system","oracle");
		  statement = connection.createStatement();

		} 
		catch (SQLException connectException) 
		{
		  System.out.println(connectException.getMessage());
		  System.out.println(connectException.getSQLState());
		  System.out.println(connectException.getErrorCode());
		  System.exit(1);
		}
    }
	
	private void loadAnswer() 
	{
		try 
		{
		  rs = statement.executeQuery("SELECT * FROM answer");
		  while (rs.next()) 
		  {
			ansidSelect.add(rs.getString("ANSID"));
		  }
		} 
		catch (SQLException e) 
		{ 
		  displaySQLErrors(e);
		}
			
	}
	
	private void loadQuestion() 
	{
		try 
		{
		  rs = statement.executeQuery("SELECT * FROM question");
		  while (rs.next()) 
		  {
			noSelect.add(rs.getString("NO"));
		  }
		} 
		catch (SQLException e) 
		{ 
		  displaySQLErrors(e);
		}
			
	}
	
	public void buildGUI() 
	{		
	    ansidSelect = new Choice();
		loadAnswer();
		
		noSelect = new Choice();
		loadQuestion();
		
	    
		//Handle Reserve Button
		crctButton = new Button("CORRECT ANSWER");
		crctButton.addActionListener(new ActionListener() 
		{
			public void actionPerformed(ActionEvent e) 
			{
				try 
				{
				  Statement statement = connection.createStatement();
				  //String query = "INSERT INTO reserves VALUES (71,101,'12-NOV-13')";				  
				  String query= "INSERT INTO crct_answer VALUES(" + noSelect.getSelectedItem() + ", " + ansidSelect.getSelectedItem()   + ")";
				  int i = statement.executeUpdate(query);
				  errorText.append("\nInserted " + i + " rows successfully");
				} 
				catch (SQLException insertException) 
				{
				  displaySQLErrors(insertException);
				}
			}
		});

		
		
		
		errorText = new TextArea(10, 40);
		errorText.setEditable(false);

		Panel first = new Panel();
		first.setLayout(new GridLayout(3, 2));
		first.add(new Label("ANSWER ID:"));
		first.add(ansidSelect);
		first.add(new Label("QUESTION ID:"));
		first.add(noSelect);
		
		

		
		Panel second = new Panel(new GridLayout(1, 1));
		second.add(crctButton);
		
		Panel third = new Panel();
		third.add(errorText);			

		add(first);
		add(second);
		add(third);
	    
		setSize(500, 600);
		setLayout(new FlowLayout());
		setVisible(true);
		
	}	

	private void displaySQLErrors(SQLException e) 
	{
		errorText.append("\nSQLException: " + e.getMessage() + "\n");
		errorText.append("SQLState:     " + e.getSQLState() + "\n");
		errorText.append("VendorError:  " + e.getErrorCode() + "\n");
	}

	

	public static void main(String[] args) 
	{
		crct_answer ca = new crct_answer();

		ca.buildGUI();
	}
}
