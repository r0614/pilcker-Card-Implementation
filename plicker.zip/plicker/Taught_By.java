import java.awt.*;
import java.awt.event.*;
import java.sql.*;
public class taught extends Panel 
{
	Button taughtButton;
	Choice sidSelect, tidSelect,subSelect;
	TextArea errorText;
	Connection connection;
	Statement statement;
	ResultSet rs;
	
	public taught()
	{
		try 
		{
			Class.forName("oracle.jdbc.driver.OracleDriver");
		} 
		catch (Exception e) 
		{
			System.err.println("Unable to find and load driver");
			System.exit(1);
		}
		connectToDB();
	}

	public void connectToDB() 
    {
		try 
		{
		  connection = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","system","oracle");
		  statement = connection.createStatement();

		} 
		catch (SQLException connectException) 
		{
		  System.out.println(connectException.getMessage());
		  System.out.println(connectException.getSQLState());
		  System.out.println(connectException.getErrorCode());
		  System.exit(1);
		}
    }
	
	private void loadStudent() 
	{
		try 
		{
		  rs = statement.executeQuery("SELECT * FROM studentd");
		  while (rs.next()) 
		  {
			sidSelect.add(rs.getString("SID"));
		  }
		} 
		catch (SQLException e) 
		{ 
		  displaySQLErrors(e);
		}			
	}
	
	private void loadInstructor() 
	{
		try 
		{
		  rs = statement.executeQuery("SELECT * FROM instructor");
		  while (rs.next()) 
		  {
			tidSelect.add(rs.getString("TID"));
		  }
		} 
		catch (SQLException e) 
		{ 
		  displaySQLErrors(e);
		}
			
	}
	
	public void buildGUI() 
	{		
	    sidSelect = new Choice();
		loadStudent();
	
		tidSelect = new Choice();
		loadInstructor();
		
	    
		//Handle Reserve Button
		taughtButton = new Button("taught");
		taughtButton.addActionListener(new ActionListener() 
		{
			public void actionPerformed(ActionEvent e) 
			{
				try 
				{
				  Statement statement = connection.createStatement();
				  //String query = "INSERT INTO reserves VALUES (71,101,'12-NOV-13')";				  
				  String query= "INSERT INTO taught VALUES(" + sidSelect.getSelectedItem() + ", " + tidSelect.getSelectedItem() + ",'" + subSelect.getSelectedItem() + "')";
				  int i = statement.executeUpdate(query);
				  errorText.append("\nInserted " + i + " rows successfully");
				} 
				catch (SQLException insertException) 
				{
				  displaySQLErrors(insertException);
				}
			}
		});

	
		
		errorText = new TextArea(10, 40);
		errorText.setEditable(false);

		Panel first = new Panel();
		first.setLayout(new GridLayout(3, 2));
		first.add(new Label("Student ID:"));
		first.add(sidSelect);
		first.add(new Label("Instructor ID:"));
		first.add(tidSelect);
		first.add(new Label("Subject:"));
		first.add(subSelect);

		
		Panel second = new Panel(new GridLayout(1, 1));
		second.add(taughtButton);
		
		Panel third = new Panel();
		third.add(errorText);			

		add(first);
		add(second);
		add(third);
	    
		setSize(500, 600);
		setLayout(new FlowLayout());
		setVisible(true);
		
	}	

	private void displaySQLErrors(SQLException e) 
	{
		errorText.append("\nSQLException: " + e.getMessage() + "\n");
		errorText.append("SQLState:     " + e.getSQLState() + "\n");
		errorText.append("VendorError:  " + e.getErrorCode() + "\n");
	}
	public static void main(String[] args) 
	{
		taught tb = new taught();

		tb.buildGUI();
	}
}
