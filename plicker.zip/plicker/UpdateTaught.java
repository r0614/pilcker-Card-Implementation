import java.awt.*;
import java.awt.event.*;
import java.sql.*;
public class UpdateTaught extends Panel 
{
	Button UpdateTaughtButton;
	List taughtIDList;
	TextField sidText, tidText, subText;
	TextArea errorText;
	Connection connection;
	Statement statement;
	ResultSet rs;
	
	public UpdateTaught() 
	{
		try 
		{
			Class.forName("oracle.jdbc.driver.OracleDriver");
		} 
		catch (Exception e) 
		{
			System.err.println("Unable to find and load driver");
			System.exit(1);
		}
		connectToDB();
	}

	public void connectToDB() 
    {
		try 
		{
		  connection = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","system","oracle");
		  statement = connection.createStatement();

		} 
		catch (SQLException connectException) 
		{
		  System.out.println(connectException.getMessage());
		  System.out.println(connectException.getSQLState());
		  System.out.println(connectException.getErrorCode());
		  System.exit(1);
		}
    }
	
	private void loadtaught() 
	{	   
		try 
		{
		  rs = statement.executeQuery("SELECT * FROM taught");
		  while (rs.next()) 
		  {
			taughtIDList.add(rs.getString("sid"));
		  }
		} 
		catch (SQLException e) 
		{ 
		  displaySQLErrors(e);
		}
	}
	
	public void buildGUI() 
	{		
	    taughtIDList = new List(6);
		loadtaught();
		add(taughtIDList);
		
		//When a list item is selected populate the text fields
		taughtIDList.addItemListener(new ItemListener()
		{
			public void itemStateChanged(ItemEvent e) 
			{
				try 
				{
					rs = statement.executeQuery("SELECT * FROM taught");
					while (rs.next()) 
					{
						if (rs.getString("sid").equals(taughtIDList.getSelectedItem()))
						break;
					}
					if (!rs.isAfterLast()) 
					{
						sidText.setText(rs.getString("sid"));
						tidText.setText(rs.getString("tid"));
						subText.setText(rs.getString("sub"));
					}
				} 
				catch (SQLException selectException) 
				{
					displaySQLErrors(selectException);
				}
			}
		});		
		
	    
		//Handle Update Sailor Button
		UpdateTaughtButton = new Button("Update taught");
		UpdateTaughtButton.addActionListener(new ActionListener()
		{
			public void actionPerformed(ActionEvent e) 
			{
				try 
				{
					Statement statement = connection.createStatement();
					int i = statement.executeUpdate("UPDATE taught "
					+ "SET tid=" + tidText.getText() + ", "
					+ "sub='" + subText.getText() + "' WHERE sid = "
					+ taughtIDList.getSelectedItem());
					errorText.append("\nUpdated " + i + " rows successfully");
					taughtIDList.removeAll();
					loadtaught();
				} 
				catch (SQLException insertException) 
				{
					displaySQLErrors(insertException);
				}
			}
		});
		
		sidText = new TextField(15);
		sidText.setEditable(false);
		tidText = new TextField(15);
		subText = new TextField(15);
		
		errorText = new TextArea(10, 40);
		errorText.setEditable(false);

		Panel first = new Panel();
		first.setLayout(new GridLayout(4, 2));
		first.add(new Label(" STUDENT ID:"));
		first.add(sidText);
		first.add(new Label("INSTRUCTOR ID :"));
		first.add(tidText);
		first.add(new Label("SUBJECT:"));
		first.add(subText);
		
		Panel second = new Panel(new GridLayout(4, 1));
		second.add(UpdateTaughtButton);
		
		Panel third = new Panel();
		third.add(errorText);
		
		add(first);
		add(second);
		add(third);
	    
		setSize(500, 600);
		setLayout(new FlowLayout());
		setVisible(true);
		
	}

	private void displaySQLErrors(SQLException e) 
	{
		errorText.append("\nSQLException: " + e.getMessage() + "\n");
		errorText.append("SQLState:     " + e.getSQLState() + "\n");
		errorText.append("VendorError:  " + e.getErrorCode() + "\n");
	}

	public static void main(String[] args) 
	{
		UpdateTaught upt = new UpdateTaught();
		
		upt.buildGUI();
	}
}
