import java.awt.*;
import java.awt.event.*;
import java.sql.*;
public class DeleteGivenQues extends Panel 
{
	Button DeleteGivenQuesButton;
	List given_quesIDList;
	TextField noText, sidText;
	TextArea errorText;
	Connection connection;
	Statement statement;
	ResultSet rs;
	
	public DeleteGivenQues() 
	{
		try 
		{
			Class.forName("oracle.jdbc.driver.OracleDriver");
		} 
		catch (Exception e) 
		{
			System.err.println("Unable to find and load driver");
			System.exit(1);
		}
		connectToDB();
	}

	public void connectToDB() 
    {
		try 
		{
		  connection = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","system","oracle");
		  statement = connection.createStatement();

		} 
		catch (SQLException connectException) 
		{
		  System.out.println(connectException.getMessage());
		  System.out.println(connectException.getSQLState());
		  System.out.println(connectException.getErrorCode());
		  System.exit(1);
		}
    }
	
	private void loadgiven_ques() 
	{	   
		try 
		{
		  rs = statement.executeQuery("SELECT * FROM given_ques");
		  while (rs.next()) 
		  {
			given_quesIDList.add(rs.getString("no"));
		  }
		} 
		catch (SQLException e) 
		{ 
		  displaySQLErrors(e);
		}
	}
	
	public void buildGUI() 
	{		
	    given_quesIDList = new List(10);
		loadgiven_ques();
		add(given_quesIDList);
		
		//When a list item is selected populate the text fields
		given_quesIDList.addItemListener(new ItemListener()
		{
			public void itemStateChanged(ItemEvent e) 
			{
				try 
				{
					rs = statement.executeQuery("SELECT * FROM given_ques");
					while (rs.next()) 
					{
						if (rs.getString("no").equals(given_quesIDList.getSelectedItem()))
						break;
					}
					if (!rs.isAfterLast()) 
					{
						noText.setText(rs.getString("no"));
						sidText.setText(rs.getString("sid"));
						
						
					}
				} 
				catch (SQLException selectException) 
				{
					displaySQLErrors(selectException);
				}
			}
		});		
		
	    
		//Handle Delete Sailor Button
		DeleteGivenQuesButton = new Button("Delete given_ques");
		DeleteGivenQuesButton.addActionListener(new ActionListener()
		{
			public void actionPerformed(ActionEvent e) 
			{
				try 
				{
					Statement statement = connection.createStatement();
					int i = statement.executeUpdate("DELETE FROM given_ques WHERE no = "
							+ given_quesIDList.getSelectedItem());
					errorText.append("\nDeleted " + i + " rows successfully");
					noText.setText(null);
					sidText.setText(null);
					
					
					given_quesIDList.removeAll();
					loadgiven_ques();
				} 
				catch (SQLException insertException) 
				{
					displaySQLErrors(insertException);
				}
			}
		});
		
		noText = new TextField(15);
		sidText = new TextField(15);
		
		
		
		errorText = new TextArea(10, 40);
		errorText.setEditable(false);

		Panel first = new Panel();
		first.setLayout(new GridLayout(4, 2));
		first.add(new Label("Question no:"));
		first.add(noText);
		first.add(new Label(" Answer :"));
		first.add(sidText);
		

		
		Panel second = new Panel(new GridLayout(4, 1));
		second.add(DeleteGivenQuesButton);
		
		Panel third = new Panel();
		third.add(errorText);
		
		add(first);
		add(second);
		add(third);
	    
		setSize(450, 600);
		setLayout(new FlowLayout());
		setVisible(true);
		
	}

	

	private void displaySQLErrors(SQLException e) 
	{
		errorText.append("\nSQLException: " + e.getMessage() + "\n");
		errorText.append("SQLState:     " + e.getSQLState() + "\n");
		errorText.append("VendorError:  " + e.getErrorCode() + "\n");
	}

	

	public static void main(String[] args) 
	{
		DeleteGivenQues delgq = new DeleteGivenQues();
		delgq.buildGUI();
	}
}
