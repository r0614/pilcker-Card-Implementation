import java.awt.*;
import java.awt.event.*;
import java.sql.*;
public class UpdateStudent extends Panel 
{
	Button updateStudentButton;
	List studentIDList;
	TextField sidText, snameText, scoreText, remarkText, classText;
	TextArea errorText;
	Connection connection;
	Statement statement;
	ResultSet rs;
	
	public UpdateStudent() 
	{
		try 
		{
			Class.forName("oracle.jdbc.driver.OracleDriver");
		} 
		catch (Exception e) 
		{
			System.err.println("Unable to find and load driver");
			System.exit(1);
		}
		connectToDB();
	}

	public void connectToDB() 
    {
		try 
		{
		  connection = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","system","oracle");
		  statement = connection.createStatement();

		} 
		catch (SQLException connectException) 
		{
		  System.out.println(connectException.getMessage());
		  System.out.println(connectException.getSQLState());
		  System.out.println(connectException.getErrorCode());
		  System.exit(1);
		}
    }
	
	private void loadStudent() 
	{	   
		try 
		{
		  rs = statement.executeQuery("SELECT * FROM studentd");
		  while (rs.next()) 
		  {
			studentIDList.add(rs.getString("SID"));
		  }
		} 
		catch (SQLException e) 
		{ 
		  displaySQLErrors(e);
		}
	}
	
	public void buildGUI() 
	{		
	    studentIDList = new List(6);
		loadStudent();
		add(studentIDList);
		
		//When a list item is selected populate the text fields
		studentIDList.addItemListener(new ItemListener()
		{
			public void itemStateChanged(ItemEvent e) 
			{
				try 
				{
					rs = statement.executeQuery("SELECT * FROM studentd");
					while (rs.next()) 
					{
						if (rs.getString("SID").equals(studentIDList.getSelectedItem()))
						break;
					}
					if (!rs.isAfterLast()) 
					{
						sidText.setText(rs.getString("SID"));
						snameText.setText(rs.getString("SNAME"));
						classText.setText(rs.getString("CLASS"));
						
						scoreText.setText(rs.getString("SCORE"));
						remarkText.setText(rs.getString("REMARK"));
					}

				} 
				catch (SQLException selectException) 
				{
					displaySQLErrors(selectException);
				}
			}
		});		
		
	    
		//Handle Update Sailor Button
		updateStudentButton = new Button("Update Student");
		updateStudentButton.addActionListener(new ActionListener()
		{
			public void actionPerformed(ActionEvent e) 
			{
				try 
				{
					Statement statement = connection.createStatement();
					int i = statement.executeUpdate("UPDATE studentd "
					+ "SET sname='" + snameText.getText()  + "', "
					+ "class=" + classText.getText() +  ", "
					+ "remark='" + remarkText.getText() +  "', "
					+ "score=" + scoreText.getText() +" WHERE sid = "
					+ studentIDList.getSelectedItem());
					errorText.append("\nUpdated " + i + " rows successfully");
					studentIDList.removeAll();
					loadStudent();
				} 
				catch (SQLException insertException) 
				{
					displaySQLErrors(insertException);
				}
			}
		});
		
		sidText = new TextField(15);
		sidText.setEditable(false);
		snameText = new TextField(15);
		classText = new TextField(15);
		scoreText = new TextField(15);
		remarkText = new TextField(15);
		
		errorText = new TextArea(10, 40);
		errorText.setEditable(false);

		Panel first = new Panel();
		first.setLayout(new GridLayout(5, 1));
		first.add(new Label("Student ID:"));
		first.add(sidText);
		first.add(new Label("Name :"));
		first.add(snameText);
		first.add(new Label("class :"));
		first.add(classText);
		first.add(new Label("Score :"));
		first.add(scoreText);
		first.add(new Label("Remark :"));
		first.add(remarkText);

		
		Panel second = new Panel(new GridLayout(4, 1));
		second.add(updateStudentButton);
		
		Panel third = new Panel();
		third.add(errorText);
		
		add(first);
		add(second);
		add(third);
	    
		setSize(500, 600);
		setLayout(new FlowLayout());
		setVisible(true);
		
	}

	private void displaySQLErrors(SQLException e) 
	{
		errorText.append("\nSQLException: " + e.getMessage() + "\n");
		errorText.append("SQLState:     " + e.getSQLState() + "\n");
		errorText.append("VendorError:  " + e.getErrorCode() + "\n");
	}

	public static void main(String[] args) 
	{
		UpdateStudent ups = new UpdateStudent();
		
		ups.buildGUI();
	}
}
