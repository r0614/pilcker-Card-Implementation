import java.awt.*; 
import java.awt.event.*; 

class plickerCard extends Frame implements ActionListener
{ 
	  String msg = ""; 
	  Label ll;
	  CardLayout cardLO;
	  
	  //Create Panels for each of the menu items, welcome screen panel and home screen panel with CardLayout
	  InsertStudent is;
	  UpdateStudent ups;
	  DeleteStudent dels;
	  InsertInstructor ii;
	  UpdateInstructor ui;
	  DeleteInstructor deli;
	  taught tb;
	  UpdateTaught upt;
	  DeleteTaught delt;
		
	  Manage_By mb;
	  UpdateManage upm;
	  DeleteManage delm;
	  
	 	InsertAdmin ia;
		UpdateAdmin upa;
		DeleteAdmin dela;
		InsertQuestion iq;
		UpdateQuestion upq;
		DeleteQuestion delq;
		InsertAnswer ian;
		UpdateAnswer upan;
		DeleteAnswer delan;
		crct_answer ca;
		UpdateCrctAnswer upansid;
		DeleteCrctAns delca;
		given_ques gq;
		UpdateGiven upg;
		DeleteGivenQues delgq;

		
	  Panel home,welcome; 
	  
	  plickerCard() 
	  { 
			cardLO = new CardLayout(); 
			
			//Create an empty home panel and set its layout to card layout 
			home = new Panel(); 
			home.setLayout(cardLO);  

			
			ll = new Label();
			ll.setAlignment(Label.CENTER);  
			ll.setText("Welcome to PLICKER CARD");
			
			//Create welcome panel and add the label to it
			welcome = new Panel();
			welcome.add(ll);		 
			
			//create panels for each of our menu items and build them with respective components
			is = new InsertStudent(); is.buildGUI();
			ups = new UpdateStudent(); ups.buildGUI();
			dels = new DeleteStudent(); dels.buildGUI();
			ui = new UpdateInstructor();	ui.buildGUI();
			ii= new InsertInstructor();	ii.buildGUI();
			deli= new DeleteInstructor(); deli.buildGUI();
			tb= new taught();	tb.buildGUI();
			upt=new UpdateTaught(); upt.buildGUI();
			ia=new InsertAdmin(); ia.buildGUI();
			upa=new UpdateAdmin(); upa.buildGUI();
			dela=new DeleteAdmin();	dela.buildGUI();
			iq=new InsertQuestion(); iq.buildGUI();
			upq=new UpdateQuestion(); upq.buildGUI();
			delq=new DeleteQuestion(); delq.buildGUI();
			ian=new InsertAnswer(); ian.buildGUI();
			upan=new UpdateAnswer(); upan.buildGUI();
			delan=new DeleteAnswer(); delan.buildGUI();
			ca=new crct_answer(); ca.buildGUI();
			upansid=new UpdateCrctAnswer(); upansid.buildGUI();
			delca=new DeleteCrctAns(); delca.buildGUI();
			gq=new given_ques(); gq.buildGUI();
			upg=new UpdateGiven(); upg.buildGUI();
			delgq=new DeleteGivenQues(); delgq.buildGUI();
			mb=new Manage_By(); mb.buildGUI();
			upm=new UpdateManage(); upm.buildGUI();
			delm=new DeleteManage(); delm.buildGUI();
			 delt=new DeleteTaught(); delt.buildGUI();
			

	
			//add all the panels to the home panel which has a cardlayout
			home.add(welcome, "Welcome"); 
			home.add(is, "InsertStudent"); 
			home.add(ups, "UpdateStudent"); 
			home.add(dels, "DeleteStudent"); 
			home.add(ii,"InsertInstructor");
			home.add(ui, "UpdateInstructor"); 
			home.add(deli,"DeleteInstructor");
			home.add(ia,"InsertAdmin");
			home.add(upa,"UpdateAdmin");
			home.add(dela,"DeleteAdmin");
			home.add(iq,"InsertQuestion");
			home.add(upq,"UpdateQuestion");
			home.add(delq,"DeleteQuestion");
			home.add(ian,"InsertAnswer");
			home.add(upan,"UpdateAnswer");
			home.add(delan,"DeleteAnswer");
			home.add(tb, "taught"); 
			home.add(upt,"UpdateTaught");
			home.add(ca,"crct_answer");
			home.add(upansid,"UpdateCrctAnswer");
			home.add(gq,"given_ques");
			home.add(upg,"UpdateGiven");
			home.add(mb,"Manage_By");
			home.add(upm,"UpdateManage");
			home.add(delm,"DeleteManage");
			home.add(delt,"DeleteTaught");
			home.add(delca,"DeleteCrctAns");
			home.add(delgq,"DeleteGivenQues");
			
		 
			// add home panel to main frame  
			add(home); 
		 
			// create menu bar and add it to frame 
			MenuBar mbar = new MenuBar(); 
			setMenuBar(mbar); 
		 
			// create the menu items and add it to Menu
			Menu Student = new Menu("Student Details"); 
			MenuItem item1, item2, item3; 
			Student.add(item1 = new MenuItem("Submit Student Details")); 
			Student.add(item2 = new MenuItem("Modify Student details")); 
			Student.add(item3 = new MenuItem("Delete Student Details")); 
			mbar.add(Student);  
		 
			Menu Instructor = new Menu("Instructor Details"); 
			MenuItem item4, item5, item6; 
			Instructor.add(item4 = new MenuItem("Submit Instructor Details ")); 
			Instructor.add(item5 = new MenuItem("Modify Instructor Details")); 
			Instructor.add(item6 = new MenuItem("Delete Instructor Details"));  
			mbar.add(Instructor); 
			
			Menu Admin= new Menu("Admin Details");
			MenuItem item10, item11, item12;
			Admin.add(item10=new MenuItem("Submit Admin Details"));
			Admin.add(item11=new MenuItem("Modify Admin Details"));

			Admin.add(item12=new MenuItem("Delete Admin Details"));
			mbar.add(Admin);
			Menu Question=new Menu("Question");
			MenuItem item13,item14, item15;
			Question.add(item13=new MenuItem("Insert Question"));
			Question.add(item14=new MenuItem("Update Question"));
			Question.add(item15=new MenuItem("Delete Question"));
			mbar.add(Question);


			Menu Answer = new Menu("Answer"); 
			MenuItem item16, item17, item18; 
			Answer.add(item16= new MenuItem("Insert Answer")); 
			Answer.add(item17= new MenuItem("Update Answer")); 
			Answer.add(item18 = new MenuItem("Delete Answer")); 
			mbar.add(Answer); 

			Menu taught = new Menu("taught_By"); 
			MenuItem item7, item8, item9; 
			taught.add(item7 = new MenuItem("Add Teacher Student pair")); 
			taught.add(item8 = new MenuItem("Update combinations")); 
			taught.add(item9 = new MenuItem("Delete a pair")); 
			mbar.add(taught); 

			Menu crct_ans = new Menu("crct_answer"); 
			MenuItem item19, item20, item21; 
			crct_ans.add(item19 = new MenuItem("Add crct_answer")); 
			crct_ans .add(item20 = new MenuItem("Update crct_answer")); 
			crct_ans .add(item21 = new MenuItem("Delete crct_answer")); 
			mbar.add(crct_ans ); 

			Menu given_ques = new Menu("given_question"); 
			MenuItem item22, item23, item24; 
			given_ques.add(item22 = new MenuItem("Add given_ques")); 
			given_ques.add(item23 = new MenuItem("Update given_ques")); 
			given_ques.add(item24 = new MenuItem("Delete given_ques")); 
			mbar.add(given_ques ); 
			
			Menu Manage_By = new Menu("Manage_By"); 
			MenuItem item25, item26, item27; 
			Manage_By .add(item25 = new MenuItem("Add Admin Student pair")); 
			Manage_By .add(item26 = new MenuItem("Update pair")); 
			Manage_By .add(item27 = new MenuItem("Delete pair")); 
			mbar.add(Manage_By ); 




			
			
			
			// register listeners
			item1.addActionListener(this); 
			item2.addActionListener(this); 
			item3.addActionListener(this); 
			item4.addActionListener(this); 
			item5.addActionListener(this); 
			item6.addActionListener(this); 
			item7.addActionListener(this); 
			item8.addActionListener(this); 
			item9.addActionListener(this); 
			item10.addActionListener(this);
			item11.addActionListener(this);
			item12.addActionListener(this);
			item13.addActionListener(this);
			item14.addActionListener(this);
			item15.addActionListener(this);
			item16.addActionListener(this);
			item17.addActionListener(this);
			item18.addActionListener(this);
			item19.addActionListener(this);
			item20.addActionListener(this);
			item21.addActionListener(this);
			item22.addActionListener(this);
			item23.addActionListener(this);
			item24.addActionListener(this);
			item25.addActionListener(this);
			item26.addActionListener(this);
			item27.addActionListener(this);










						
					
			 // Anonymous inner class which extends WindowAdaptor to handle the Window event: windowClosing  
			addWindowListener(new WindowAdapter(){
				public void windowClosing(WindowEvent we) 
				{ 
					System.exit(0);	
				} 
			}); 
			
			//Frame properties
			setTitle("PLICKER CARD"); 
			Color clr = new Color(200, 100, 150);
			setBackground(clr); 
			setFont(new Font("SansSerif", Font.BOLD, 14)); 
			setSize(500, 600); 
			setVisible(true);	
			
	  }   
	  
	  public void actionPerformed(ActionEvent ae) 
	  { 
		  String arg = ae.getActionCommand(); 
		  if(arg.equals("Submit Student Details"))
		  {
			cardLO.show(home, "InsertStudent"); 			
          	 }			
		 
		 else if(arg.equals("Modify Student details")) 
		 {
			cardLO.show(home, "UpdateStudent"); 			
		 }
		 
		 else if(arg.equals("Delete Student Details")) 
		 {
			cardLO.show(home, "DeleteStudent"); 			
		 }
		else if(arg.equals("Submit Instructor Details"))
		{
			cardLO.show(home,"InsertInstructor");
		}
		 
		 else if(arg.equals("Modify Instructor Details")) 
		 {
			cardLO.show(home, "UpdateInstructor"); 				
		 }
		else if(arg.equals("Delete Instructor Details"))
		{
			cardLO.show(home,"DeleteInstructor");
		}
		else if(arg.equals("Submit Admin Details"))
		{
			cardLO.show(home,"InsertAdmin");
		}

		else if(arg.equals("Update Admin Details"))
		{
			cardLO.show(home,"UpdateAdmin");
		}
		else if(arg.equals("Delete Admin Details"))
		{
			cardLO.show(home,"DeleteAdmin");
		}
		else if(arg.equals("Insert Question"))
		{
			cardLO.show(home,"InsertQuestion");
		}

		else if(arg.equals("Update Question"))
		{
			cardLO.show(home,"UpdateQuestion");
		}
		else if(arg.equals("Delete Question"))
		{
			cardLO.show(home,"DeleteQuestion");
		}
		else if(arg.equals("Insert Answer"))
		{
			cardLO.show(home,"InsertAnswer");
		}

		else if(arg.equals("Update Answer"))
		{
			cardLO.show(home,"UpdateAnswer");
		}
		else if(arg.equals("Delete Answer"))
		{
			cardLO.show(home,"DeleteAnswer");
		}
		else if(arg.equals("Add crct_answer"))
		{
			cardLO.show(home,"crct_answer");
		}
		else if(arg.equals("Update crct_answer"))
		{
			cardLO.show(home,"UpdateCrctAnswer");
		}
		else if(arg.equals("Delete crct_answer"))
		{
			cardLO.show(home,"DeleteCrctAns");
		}
		else if(arg.equals("Add given_ques"))
		{
			cardLO.show(home,"given_ques");
		}
		else if(arg.equals("Update given_ques"))
		{
			cardLO.show(home,"UpdateGiven");
		}
		else if(arg.equals("Delete given_ques"))
		{
			cardLO.show(home,"DeleteGivenQues");
		}


		else if(arg.equals("Update Answer"))
		{
			cardLO.show(home,"UpdateAnswer");
		}
		else if(arg.equals("Delete Answer"))
		{
			cardLO.show(home,"DeleteAnswer");
		}
			
		 else if(arg.equals("Add Teacher Student pair")) 
		 {
			cardLO.show(home, "taught"); 				
		 }
		 else if(arg.equals("View combinations")) 
		 {
			cardLO.show(home, "UpdateTaught"); 				
		 }
		  else if(arg.equals("Delete a pair")) 
		 {
			cardLO.show(home, "DeleteTaught"); 				
		 }
			
		 else if(arg.equals("Add Admin Student pair")) 
		 {
			cardLO.show(home, "Manage_By"); 				
		 }
		 else if(arg.equals("Update pair")) 
		 {
			cardLO.show(home, "UpdateManage"); 				
		 }
		 else if(arg.equals("Delete pair")) 
		 {
			cardLO.show(home, "DeleteManage"); 				
		 }				 
	  }
	  public static void main(String ... args)
	  {
			new plickerCard();	  
	  }
} 
 

 
