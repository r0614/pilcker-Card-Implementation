import java.awt.*;
import java.awt.event.*;
import java.sql.*;
public class given_ques extends Panel 
{
	Button givenButton;
	
	Choice sidSelect, noSelect;
	TextArea errorText;
	Connection connection;
	Statement statement;
	ResultSet rs;
	
	public given_ques() 
	{
		try 
		{
			Class.forName("oracle.jdbc.driver.OracleDriver");
		} 
		catch (Exception e) 
		{
			System.err.println("Unable to find and load driver");
			System.exit(1);
		}
		connectToDB();
	}

	public void connectToDB() 
    {
		try 
		{
		  connection = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","system","oracle");
		  statement = connection.createStatement();

		} 
		catch (SQLException connectException) 
		{
		  System.out.println(connectException.getMessage());
		  System.out.println(connectException.getSQLState());
		  System.out.println(connectException.getErrorCode());
		  System.exit(1);
		}
    }
	
	private void loadStudent() 
	{
		try 
		{
		  rs = statement.executeQuery("SELECT * FROM Studentd");
		  while (rs.next()) 
		  {
			sidSelect.add(rs.getString("SID"));
		  }
		} 
		catch (SQLException e) 
		{ 
		 displaySQLErrors(e);
		}
			
	}
	
	private void loadQuestion() 
	{
		try 
		{
		  rs = statement.executeQuery("SELECT * FROM Question");
		  while (rs.next()) 
		  {
			noSelect.add(rs.getString("NO"));
		  }
		} 
		catch (SQLException e) 
		{ 
		  displaySQLErrors(e);
		}
			
	}
	
	public void buildGUI() 
	{		
	    sidSelect = new Choice();
		loadStudent();
		
		noSelect = new Choice();
		loadQuestion();
		
	    
		//Handle Reserve Button
		givenButton = new Button("Given_Question");
		givenButton.addActionListener(new ActionListener() 
		{
			public void actionPerformed(ActionEvent e) 
			{
				try 
				{
				  Statement statement = connection.createStatement();
				  //String query = "INSERT INTO reserves VALUES (71,101,'12-NOV-13')";				  
				  String query= "INSERT INTO given_ques VALUES(" + sidSelect.getSelectedItem() + ", " + noSelect.getSelectedItem()  + ")";
				  int i = statement.executeUpdate(query);
				  errorText.append("\nInserted " + i + " rows successfully");
				} 
				catch (SQLException insertException) 
				{
				  displaySQLErrors(insertException);
				}
			}
		});

		
		
		
		errorText = new TextArea(10, 40);
		errorText.setEditable(false);

		Panel first = new Panel();
		first.setLayout(new GridLayout(3, 2));
		first.add(new Label("Student ID:"));
		first.add(sidSelect);
		first.add(new Label("Question ID:"));
		first.add(noSelect);
		
		
		
		Panel second = new Panel(new GridLayout(1, 1));
		second.add(givenButton);
		
		Panel third = new Panel();
		third.add(errorText);			

		add(first);
		add(second);
		add(third);
	    
		setSize(500, 600);
		setLayout(new FlowLayout());
		setVisible(true);
		
	}	

	private void displaySQLErrors(SQLException e) 
	{
		errorText.append("\nSQLException: " + e.getMessage() + "\n");
		errorText.append("SQLState:     " + e.getSQLState() + "\n");
		errorText.append("VendorError:  " + e.getErrorCode() + "\n");
	}

	

	public static void main(String[] args) 
	{
		given_ques gq = new given_ques();

		gq.buildGUI();
	}
}
