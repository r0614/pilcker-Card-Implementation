import java.awt.*;
import java.awt.event.*;
import java.sql.*;
public class UpdateAnswer extends Panel 
{
	Button UpdateAnswerButton;
	List AnswerIDList;
	TextField ansidText, opt1Text, opt2Text, opt3Text, opt4Text;
	TextArea errorText;
	Connection connection;
	Statement statement;
	ResultSet rs;
	
	public UpdateAnswer() 
	{
		try 
		{
			Class.forName("oracle.jdbc.driver.OracleDriver");
		} 
		catch (Exception e) 
		{
			System.err.println("Unable to find and load driver");
			System.exit(1);
		}
		connectToDB();
	}

	public void connectToDB() 
    {
		try 
		{
		  connection = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","system","oracle");
		  statement = connection.createStatement();

		} 
		catch (SQLException connectException) 
		{
		  System.out.println(connectException.getMessage());
		  System.out.println(connectException.getSQLState());
		  System.out.println(connectException.getErrorCode());
		  System.exit(1);
		}
    }
	
	private void loadAnswer() 
	{	   
		try 
		{
		  rs = statement.executeQuery("SELECT * FROM Answer");
		  while (rs.next()) 
		  {
			AnswerIDList.add(rs.getString("ansid"));
		  }
		} 
		catch (SQLException e) 
		{ 
		  displaySQLErrors(e);
		}
	}
	
	public void buildGUI() 
	{		
	    AnswerIDList = new List(6);
		loadAnswer();
		add(AnswerIDList);
		
		//When a list item is selected populate the text fields
		AnswerIDList.addItemListener(new ItemListener()
		{
			public void itemStateChanged(ItemEvent e) 
			{
				try 
				{
					rs = statement.executeQuery("SELECT * FROM Answer");
					while (rs.next()) 
					{
						if (rs.getString("ansid").equals(AnswerIDList.getSelectedItem()))
						break;
					}
					if (!rs.isAfterLast()) 
					{
						ansidText.setText(rs.getString("ansid"));
						opt1Text.setText(rs.getString("OPT1"));
						opt2Text.setText(rs.getString("OPT2"));
						opt3Text.setText(rs.getString("OPT3"));
						opt4Text.setText(rs.getString("OPT4"));
					}
				} 
				catch (SQLException selectException) 
				{
					displaySQLErrors(selectException);
				}
			}
		});		
		
	    
		//Handle Update Sailor Button
		UpdateAnswerButton = new Button("Update Answer");
		UpdateAnswerButton.addActionListener(new ActionListener()
		{
			public void actionPerformed(ActionEvent e) 
			{
				try 
				{
					Statement statement = connection.createStatement();
					int i = statement.executeUpdate("UPDATE Answer "
					+ "SET opt1='" + opt1Text.getText()  + "', "
					+ "opt4='" + opt4Text.getText() +  "', "
					+ "opt3='" + opt3Text.getText() +  "', "
					+ "opt2='" + opt2Text.getText() +"' WHERE ansid = "
					+ AnswerIDList.getSelectedItem());
					errorText.append("\nUpdated " + i + " rows successfully");
					AnswerIDList.removeAll();
					loadAnswer();
				} 
				catch (SQLException insertException) 
				{
					displaySQLErrors(insertException);
				}
			}
		});
		
		ansidText = new TextField(15);
		ansidText.setEditable(false);
		opt1Text = new TextField(15);
		opt2Text = new TextField(15);
		opt3Text = new TextField(15);
		opt4Text = new TextField(15);
		
		errorText = new TextArea(10, 40);
		errorText.setEditable(false);

		Panel first = new Panel();
		first.setLayout(new GridLayout(5, 2));
		first.add(new Label("Answer ID:"));
		first.add(ansidText);
		first.add(new Label("option 1 :"));
		first.add(opt1Text);
		first.add(new Label("option 2 :"));
		first.add(opt4Text);
		first.add(new Label("option 3 :"));
		first.add(opt2Text);
		first.add(new Label("option 4 :"));
		first.add(opt3Text);

		
		Panel second = new Panel(new GridLayout(4, 1));
		second.add(UpdateAnswerButton);
		
		Panel third = new Panel();
		third.add(errorText);
		
		add(first);
		add(second);
		add(third);
	    
		setSize(500, 600);
		setLayout(new FlowLayout());
		setVisible(true);
		
	}

	private void displaySQLErrors(SQLException e) 
	{
		errorText.append("\nSQLException: " + e.getMessage() + "\n");
		errorText.append("SQLState:     " + e.getSQLState() + "\n");
		errorText.append("VendorError:  " + e.getErrorCode() + "\n");
	}

	public static void main(String[] args) 
	{
		UpdateAnswer upa= new UpdateAnswer();
		
		upa.buildGUI();
	}
}
