
import java.awt.*;
import java.awt.event.*;
import java.sql.*;
public class DeleteQuestion extends Panel 
{
	Button deleteQuestionButton;
	List QuestionIDList;
	TextField noText, quesText, marksText;
	TextArea errorText;
	Connection connection;
	Statement statement;
	ResultSet rs;
	
	public DeleteQuestion() 
	{
		try 
		{
			Class.forName("oracle.jdbc.driver.OracleDriver");
		} 
		catch (Exception e) 
		{
			System.err.println("Unable to find and load driver");
			System.exit(1);
		}
		connectToDB();
	}

	public void connectToDB() 
    {
		try 
		{
		  connection = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","system","oracle");
		  statement = connection.createStatement();

		} 
		catch (SQLException connectException) 
		{
		  System.out.println(connectException.getMessage());
		  System.out.println(connectException.getSQLState());
		  System.out.println(connectException.getErrorCode());
		  System.exit(1);
		}
    }
	
	private void loadQuestion() 
	{	   
		try 
		{
		  rs = statement.executeQuery("SELECT * FROM question");
		  while (rs.next()) 
		  {
			QuestionIDList.add(rs.getString("NO"));
		  }
		} 
		catch (SQLException e) 
		{ 
		  displaySQLErrors(e);
		}
	}
	
	public void buildGUI() 
	{		
	    QuestionIDList = new List(10);
		loadQuestion();
		add(QuestionIDList);
		
		//When a list item is selected populate the text fields
		QuestionIDList.addItemListener(new ItemListener()
		{
			public void itemStateChanged(ItemEvent e) 
			{
				try 
				{
					rs = statement.executeQuery("SELECT * FROM question");
					while (rs.next()) 
					{
						if (rs.getString("NO").equals(QuestionIDList.getSelectedItem()))
						break;
					}
					if (!rs.isAfterLast()) 
					{
						noText.setText(rs.getString("NO"));
						quesText.setText(rs.getString("QUES"));
						marksText.setText(rs.getString("MARKS"));
						
					}
				} 
				catch (SQLException selectException) 
				{
					displaySQLErrors(selectException);
				}
			}
		});		
		
	    
		//Handle Delete Sailor Button
		deleteQuestionButton = new Button("Delete Question");
		deleteQuestionButton.addActionListener(new ActionListener()
		{
			public void actionPerformed(ActionEvent e) 
			{
				try 
				{
					Statement statement = connection.createStatement();
					int i = statement.executeUpdate("DELETE FROM question WHERE NO = "
							+ QuestionIDList.getSelectedItem());
					errorText.append("\nDeleted " + i + " rows successfully");
					noText.setText(null);
					quesText.setText(null);
					marksText.setText(null);
					
					QuestionIDList.removeAll();
					loadQuestion();
				} 
				catch (SQLException insertException) 
				{
					displaySQLErrors(insertException);
				}
			}
		});
		
		noText = new TextField(15);
		quesText = new TextField(15);
		marksText = new TextField(15);
		
		
		errorText = new TextArea(10, 40);
		errorText.setEditable(false);

		Panel first = new Panel();
		first.setLayout(new GridLayout(5, 2));
		first.add(new Label("Question no:"));
		first.add(noText);
		first.add(new Label("Question:"));
		first.add(quesText);
		first.add(new Label("Marks:"));
		first.add(marksText);
		
		
		
		Panel second = new Panel(new GridLayout(5,1));
		second.add(deleteQuestionButton);
		
		Panel third = new Panel();
		third.add(errorText);
		
		add(first);
		add(second);
		add(third);
	    
		setSize(450, 600);
		setLayout(new FlowLayout());
		setVisible(true);
		
	}

	private void displaySQLErrors(SQLException e) 
	{
		errorText.append("\nSQLException: " + e.getMessage() + "\n");
		errorText.append("SQLState:     " + e.getSQLState() + "\n");
		errorText.append("VendorError:  " + e.getErrorCode() + "\n");
	}

	

	public static void main(String[] args) 
	{
		DeleteQuestion delq = new DeleteQuestion();
		delq.buildGUI();
	}
}
